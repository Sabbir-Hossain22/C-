#include <iostream>
#include "UnsortedType.cpp"

class studentInfo {
public:
    int studentID;
    std::string name;
    double cgpa;

    // Default constructor
    studentInfo() : studentID(0), name(""), cgpa(0.0) {}

    studentInfo(int id, const std::string& n, double g) : studentID(id), name(n), cgpa(g) {}

    void printInfo() {
        std::cout << studentID << ", " << name << ", " << cgpa << std::endl;
    }

    bool operator==(const studentInfo& other) const {
        return studentID == other.studentID;
    }

    bool operator!=(const studentInfo& other) const {
        return !(*this == other);
    }
};
int main() {
    UnsortedType<int> intList;
    UnsortedType<studentInfo> studentList;

    // Insert integers
    intList.InsertItem(5);
    intList.InsertItem(7);
    intList.InsertItem(6);
    intList.InsertItem(9);

    // Print the list
    int length = intList.LengthIs();
    for (int i = 0; i < length; ++i) {
        int currentItem;
        intList.GetNextItem(currentItem);
        std::cout << currentItem << " ";
    }
    std::cout << std::endl;

    // Print the length of the list
    std::cout << "Length of the list: " << intList.LengthIs() << std::endl;

    // Insert one item
    intList.InsertItem(1);

    // Print the updated list
    intList.ResetList();
    length = intList.LengthIs();
    for (int i = 0; i < length; ++i) {
        int currentItem;
        intList.GetNextItem(currentItem);
        std::cout << currentItem << " ";
    }
    std::cout << std::endl;

    // Retrieve and print whether items are found
    bool found;
    int itemToRetrieve;

    itemToRetrieve = 4;
    intList.RetrieveItem(itemToRetrieve, found);
    std::cout << "Item 4 is " << (found ? "found" : "not found") << std::endl;

    itemToRetrieve = 5;
    intList.RetrieveItem(itemToRetrieve, found);
    std::cout << "Item 5 is " << (found ? "found" : "not found") << std::endl;

    itemToRetrieve = 9;
    intList.RetrieveItem(itemToRetrieve, found);
    std::cout << "Item 9 is " << (found ? "found" : "not found") << std::endl;

    itemToRetrieve = 10;
    intList.RetrieveItem(itemToRetrieve, found);
    std::cout << "Item 10 is " << (found ? "found" : "not found") << std::endl;

    // Print if the list is full or not
    std::cout << "List is " << (intList.IsFull() ? "full" : "not full") << std::endl;

    // Delete items
    intList.DeleteItem(5);

    // Print if the list is full or not
    std::cout << "List is " << (intList.IsFull() ? "full" : "not full") << std::endl;

    // Delete items
    intList.DeleteItem(1);

    // Print the updated list
    intList.ResetList();
    length = intList.LengthIs();
    for (int i = 0; i < length; ++i) {
        int currentItem;
        intList.GetNextItem(currentItem);
        std::cout << currentItem << " ";
    }
    std::cout << std::endl;

    // Delete items
    intList.DeleteItem(6);

    // Print the updated list
    intList.ResetList();
    length = intList.LengthIs();
    for (int i = 0; i < length; ++i) {
        int currentItem;
        intList.GetNextItem(currentItem);
        std::cout << currentItem << " ";
    }
    std::cout << std::endl;

    // Insert student records
    studentList.InsertItem(studentInfo(15234, "Jon", 2.6));
    studentList.InsertItem(studentInfo(13732, "Tyrion", 3.9));
    studentList.InsertItem(studentInfo(13569, "Sandor", 1.2));
    studentList.InsertItem(studentInfo(15467, "Ramsey", 3.1));
    studentList.InsertItem(studentInfo(16285, "Arya", 3.1));

    // Delete a student record by ID
    studentList.DeleteItem(studentInfo(15467, "", 0.0));

    // Retrieve and print a student record by ID
    itemToRetrieve = 13569;
    studentInfo foundStudent(0, "", 0.0);
    studentList.RetrieveItem(foundStudent, found);
    std::cout << "Student " << itemToRetrieve << " is " << (found ? "found" : "not found") << std::endl;
    if (found) {
        foundStudent.printInfo();
    }

    // Print the list of student records
    studentList.ResetList();
    length = studentList.LengthIs();
    for (int i = 0; i < length; ++i) {
        studentInfo currentItem(0, "", 0.0);
        studentList.GetNextItem(currentItem);
        currentItem.printInfo();
    }

    return 0;
}
