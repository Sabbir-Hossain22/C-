#include <iostream>
#include "dynArr.h"
using namespace std;

int main()
{
    dynArr obj1;
    dynArr obj2(5);
    int inputValue;
    for (int i= 0; i<5; ++i)
    {
        cout << "Enter the value"<<i+1<<": ";
        cin >> inputValue;
        obj2.setValue(i, inputValue);
    }
    cout<<"values stored in obj2 : ";
    for (int i =0; i< 5; ++i)
    {
        cout <<obj2.getValue(i)<<" ";
    }
    cout <<endl;

    return 0;
}
