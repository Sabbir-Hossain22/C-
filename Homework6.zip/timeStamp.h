#ifndef TIMESTAMP_H_INCLUDED
#define TIMESTAMP_H_INCLUDED

class timeStamp {
public:
    int seconds;
    int minutes;
    int hours;

    timeStamp(int s, int m, int h);
    void printTime() const;
    bool operator<(const timeStamp& other) const;
};

#include "timeStamp.cpp"
#endif // TIMESTAMP_H_INCLUDED
