#include <iostream>
#include "sortedtype.cpp"
using namespace std;

class timeStamp
{
public:
    int seconds, minutes, hours;
    timeStamp() {}
    timeStamp(int seconds, int minutes, int hours)
    {
      this->seconds = seconds;
       this->minutes = minutes;
      this->hours = hours;
    }
    bool operator<( timeStamp &other)
    {
        if (hours < other.hours)
            return true;
        else if (hours == other.hours)
        {
            if (minutes < other.minutes)
                return true;
            else if (minutes == other.minutes)
            {
                return seconds < other.seconds;
            }
        }
        return false;
    }

    bool operator>( timeStamp &other)
    {
        return other < *this;
    }
    bool operator!=( timeStamp &other)
    {
        return !(*this == other);
    }
    bool operator==( timeStamp &other)
    {
        return (hours == other.hours) && (minutes == other.minutes) && (seconds == other.seconds);
    }
    void printTime()
    {
        cout << seconds << ":" << minutes << ":" << hours << endl;
    }
};

int main()
{
    SortedType<int>st;

    st.InsertItem(5);
    st.InsertItem(7);
    st.InsertItem(4);
    st.InsertItem(2);
    st.InsertItem(1);
    int input;
    for (int i =0; i<st.LengthIs(); i++)
    {
        st.GetNextItem(input);
        cout<<input<<" ";
    }
    cout<< endl;
    int a = 6;
    bool f;
    st.RetrieveItem(a, f);
    cout << "Item of " << a << " is found: " << f << endl;

    a = 5;
    st.RetrieveItem(a, f);
    cout << "Item of" << a << " is found: " << f << endl;

    if (st.IsFull())
    {
        cout << "List is full" << endl;
    }
    else
    {
        cout << "List is not full" << endl;
    }

    st.DeleteItem(1);
    st.ResetList();
    for (int i = 0; i < st.LengthIs(); i++)
    {
        st.GetNextItem(input);
        cout << input << " ";
    }
    cout << endl;

    if (st.IsFull())
    {
        cout << "List is full" << endl;
    }
    else
    {
        cout << "List is not full" << endl;
    }

    SortedType<timeStamp> st2;
    st2.InsertItem(timeStamp(15, 34, 23));
    st2.InsertItem(timeStamp(13, 13, 2));
    st2.InsertItem(timeStamp(43, 45, 12));
    st2.InsertItem(timeStamp(25, 36, 17));
    st2.InsertItem(timeStamp(52, 2, 20));

    st2.DeleteItem(timeStamp(25, 36, 17));
    st2.ResetList();

    for (int i = 0; i < st2.LengthIs(); i++)
    {
        timeStamp ts;
        st2.GetNextItem(ts);
        ts.printTime();
        cout<<endl;
    }

    return 0;
}
