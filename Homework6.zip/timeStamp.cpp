#include "timeStamp.h"
#include <iostream>
#include <iomanip>

timeStamp::timeStamp(int s, int m, int h) : seconds(s), minutes(m), hours(h) {}

void timeStamp::printTime() const {
    std::cout << std::setfill('0') << std::setw(2) << hours << ":" << std::setw(2) << minutes << ":" << std::setw(2) << seconds;
}

bool timeStamp::operator<(const timeStamp& other) const {
    if (hours < other.hours) return true;
    if (hours > other.hours) return false;
    if (minutes < other.minutes) return true;
    if (minutes > other.minutes) return false;
    return seconds < other.seconds;
}
