#include "timeStamp.h"

timeStamp::timeStamp()
{
    ss = 0;
    mm = 0;
    hh = 0;
}

timeStamp::timeStamp(int s, int m, int h)
{
    ss = s;
    mm = m;
    hh = h;
}

int timeStamp::getSS()
{
    return ss;
}
int timeStamp::getMM()
{
    return mm;
}
int timeStamp::getHH()
{
    return hh;
}

void timeStamp::setSS(int s)
{
    ss = s;
}

void timeStamp::setMM(int m)
{
    mm = m;
}

void timeStamp::setHH(int h)
{
    hh = h;
}

bool timeStamp::operator==(timeStamp t)
{
    return (hh==t.hh) && (mm==t.mm) && (ss==t.ss);
}

bool timeStamp::operator!=(timeStamp t)
{
    return (hh != t.hh) || (mm != t.mm) || (ss != t.ss);
}

bool timeStamp::operator<(timeStamp obj)
{
    //int secs1 = hh*3600 + mm*60 + ss;
    //int secs2 = t.hh*3600 + t.mm*60 + t.ss;
    //return secs1 > secs2;

    if(this->hh<obj.hh)
        return true;

    else if(this->hh==obj.hh)
    {
        if(this->mm<obj.mm)
            return true;
        else if(this->mm==obj.mm)
            return(this->ss<obj.ss);
        else
            return false;
    }

    else //this-h>obj.h
        return true;
}

bool timeStamp::operator>(timeStamp t)
{
    //int secs1 = hh*3600 + mm*60 + ss;
    //int secs2 = t.hh*3600 + t.mm*60 + t.ss;
    //return secs1 < secs2;

    if(this->hh>t.hh) return true;
    else if(this->hh == t.hh)
    {
        if(this->mm > t.mm) return true;
        else if(this->mm == t.mm)
        {
            if(this->ss > t.ss) return true;
            else return false;
        }
    }
    else return true;

    //return true;
}

ostream& operator<<(ostream &os, const timeStamp &t)
{
    os << t.ss << ":" << t.mm << ":" << t.hh;
    return os;
}



