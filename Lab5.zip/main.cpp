#include <iostream>
#include "sortedtype.h"
#include "sortedtype.cpp"
#include "timeStamp.h"
using namespace std;

void printList(SortedType<timeStamp> timeStampList){
    timeStamp temp;
    for (int i = 0; i < timeStampList.LengthIs(); ++i)
    {
        timeStampList.GetNextItem(temp);
        cout << temp << endl;
    }
}

int main()
{
    SortedType<timeStamp> timeStampList;
    timeStamp t1(15, 34, 23);
    timeStamp t2(13, 13, 02);
    timeStamp t3(43, 45, 12);
    timeStamp t4(25, 36, 17);
    timeStamp t5(52, 02, 20);


    timeStampList.InsertItem(t1);
    timeStampList.InsertItem(t2);
    timeStampList.InsertItem(t3);
    timeStampList.InsertItem(t4);
    timeStampList.InsertItem(t5);


    timeStamp temp(25, 36, 17);
    timeStampList.DeleteItem(temp);

    //printList(timeStampList);
    for (int i = 0; i < timeStampList.LengthIs(); i++)
    {
        timeStampList.GetNextItem(temp);
        cout << temp << endl;
    }

    return 0;
}
