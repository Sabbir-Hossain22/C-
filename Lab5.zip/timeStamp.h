#ifndef TIMESTAMP_H_INCLUDED
#define TIMESTAMP_H_INCLUDED
#include<iostream>
using namespace std;

class timeStamp
{
    public:
        timeStamp();
    	timeStamp(int s, int m, int h);
    	bool operator==(timeStamp t);
    	bool operator!=(timeStamp t);
    	bool operator<(timeStamp t);
    	bool operator>(timeStamp t);
    	int getSS();
    	int getMM();
    	int getHH();
    	void setSS(int s);
    	void setMM(int m);
    	void setHH(int h);

       	friend ostream& operator <<(ostream &os, const timeStamp& timestamp);
        //friend istream& operator >>(istream &is, const timeStamp& timestamp);

    private:
    	int ss;
    	int mm;
    	int hh;
};
#endif // TIMESTAMP_H_INCLUDED
