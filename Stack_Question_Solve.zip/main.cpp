#include <iostream>
#include <stack>
#include"stacktype.cpp"
using namespace std;

double evaluate(char oprt, double num1, double num2) {
    switch (oprt) {
        case '+':
            return num1 + num2;
        case '-':
            return num1 - num2;
        case '*':
            return num1 * num2;
        case '/':
            return num1 / num2;
        default:
            return 0;
    }
}

bool isOperator(char ch) {
    return (ch == '+' || ch == '-' || ch == '*' || ch == '/' );
}

bool isNumber(char ch) {
    return (ch >= '0' && ch <= '9');
}

int precedence(char ch) {
    switch (ch) {

        case '*':
        case '/':
            return 2;
        case '+':
        case '-':
            return 1;

        default:
            return -1;
    }
}
int main() {
    stack<char> operators;

    string expression;

    cout<<"Enter your expression : "<<endl;
    getline(cin, expression);

    string postfix;
    string temp;

    bool unbalanced = false;


    for (char ch : expression) {
        if (isNumber(ch)) {
            temp += ch;
        } else {
            if (temp != "") {
                postfix += temp;
                temp = "";
                postfix += '.';
            }

            if (isOperator(ch)) {
                while (!operators.empty() && precedence(ch) <= precedence(operators.top())) {
                    postfix += operators.top();
                    operators.pop();
                }

                operators.push(ch);
            } else if (ch == '(') {
                operators.push('(');
            } else if (ch == ')') {
                bool found = false;

                while (!operators.empty() && operators.top() != '(') {
                    postfix += operators.top();
                    operators.pop();

                    if (operators.top() == '(') {
                        found = true;
                    }
                }

                if (!found) {
                    unbalanced = true;
                    break;
                } else
                    operators.pop();
            } else
                continue;
        }
    }

    if (temp != "") {
        postfix += temp;
    }
    if (!operators.empty()) {
        while (!operators.empty()) {
            postfix += operators.top();
            operators.pop();
        }
    }

    double result = 0;
    stack<double> operands;

    int index = 0;
    while (index < postfix.length()) {
        if (isNumber(postfix[index])) {
            string temp = "";

            while (isNumber(postfix[index])) {
                temp += postfix[index];
                index++;
            }

            double t = stoi(temp);
            operands.push(t);
        } else if (isOperator(postfix[index])) {
            if (operands.empty()) {
                unbalanced = true;
                break;
            }
            double t1 = operands.top();
            operands.pop();
            if (operands.empty()) {
                unbalanced = true;
                break;
            }
            double t2 = operands.top();
            operands.pop();

            double t = evaluate(postfix[index], t2, t1);
            operands.push(t);
            index++;
        } else
            index++;
    }

    if (unbalanced || operands.empty())
        {
        cout << "Invalid expression"<<endl;

    }
     else
        cout << operands.top();

    return 0;
}
