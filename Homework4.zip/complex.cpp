#include "complex.h"
#include <iostream>
using namespace std;

template <class T>
Complex<T>::Complex()
{
    Real = 0;
    Imaginary = 0;
}

template <class T>
Complex<T>::Complex(T r, T i)
{
    Real = r;
    Imaginary = i;
}

template <class T>
Complex<T> Complex<T>::operator*(Complex a)
{
    Complex<T> t;
    t.Real = Real * a.Real - Imaginary * a.Imaginary;
    t.Imaginary = Real * a.Imaginary + Imaginary * a.Real;
    return t;
}

template <class T>
bool Complex<T>::operator!=(Complex a)
{
    return Real != a.Real || Imaginary != a.Imaginary;
}

template <class T>
void Complex<T>::Print()
{
    cout << Real << endl;
    cout << Imaginary ;
}
