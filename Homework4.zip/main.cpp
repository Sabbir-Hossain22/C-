#include <iostream>
#include "complex.cpp"
#include "complex.h"
using namespace std;

int main() {
    Complex<double> c1(1.0, 2.0);
    Complex<double> c2(3.0, 4.0);

    Complex<double> c3 = c1 * c2;

    c3.Print();
    cout << endl;


    return 0;
}
