#ifndef COMPLEX_H_INCLUDED
#define COMPLEX_H_INCLUDED

template <class T>
class Complex {
public:
    Complex();
    Complex(T r, T i);
    Complex operator*(Complex);
    bool operator!=(Complex);
    void Print();

private:
    T Real, Imaginary;
};

#endif // COMPLEX_H_INCLUDED
