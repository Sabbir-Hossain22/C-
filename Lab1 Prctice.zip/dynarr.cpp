#include "dynarr.h"
#include <iostream>
using namespace std;
dynArr::dynArr()
{
    data = NULL;
    rows= 0;
    cols =0;
}
dynArr::dynArr(int r, int c)
{
    data = new int*[r];
    for(int i=0; i<r; i++)
    {
        data[i]=new int[c];
    }
    rows =r;
    cols =c;

}
dynArr::~dynArr()
{
    for(int i=0; i<rows; i++)
    {
        delete [] data[i];
    }
    delete [] data;
}
int dynArr::getValue(int row, int col)
{
    return data [row][col];
}
void dynArr::setValue(int row,int col, int value)
{
    data[row][col] = value;
}
void dynArr::allocate(int r, int c)
{
    if (data !=NULL)
    {
        for (int i=0; i<rows; i++)
        {
            delete [] data[i];
        }
        delete [] data;
    }
    data = new int*[r];
    for(int i=0; i<r; i++)
    {
        data[i] = new int [c];
    }
    rows =r;
    cols =c;
}
