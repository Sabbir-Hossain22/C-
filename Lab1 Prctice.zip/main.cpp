#include <iostream>
#include "dynarr.h"
using namespace std;

int main()
{

    //task 1 of lab2 ;


    /*dynArr obj1;
    dynArr obj2 (5);

    for(int i =0; i<5; i++)
    {
        int value;
        cin>>value;
        obj2.setValue(i, value);
    }
    cout<<"The values stored in the second object are: ";
    for(int i =0; i<5; i++)
    {
        cout << obj2.getValue(i)<<" ";
    }
    cout << endl;*/



    //task 2 of lab2


   /* dynArr obj(5);
    obj.allocate(6);
    obj.setValue(5,10);
    cout<<obj.getValue(5)<<endl;*/

    //task 3 lab 2

  dynArr arr; // Declare the variable 'arr' once

  // Take input from the user for the number of rows, columns, and elements of the array
  int rows, cols;

  cout << "Enter the number of rows and columns: ";
  cin >> rows >> cols;

  arr.allocate(rows, cols);

  for (int i = 0; i < rows; i++) {
    for (int j = 0; j < cols; j++) {
      int value;
      cout << "Enter the value for row " << i << ", column " << j << ": ";
      cin >> value;
      arr.setValue(i, j, value);
    }
  }

  // Print the contents of the array
  for (int i = 0; i < rows; i++) {
    for (int j = 0; j < cols; j++) {
      cout << arr.getValue(i, j) << " ";
    }
    cout << endl;
  }

    return 0;
}
