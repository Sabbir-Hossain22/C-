#include <iostream>
#include "unsortedtype.h"
#include "unsortedtype.cpp"
#include "studentInfo.cpp"


using namespace std;

int main()
{
    UnsortedType <int> ut;
    ut.InsertItem(5);
    ut.InsertItem(7);
    ut.InsertItem(6);
    ut.InsertItem(9);
    int input;
    for (int i=0; i<ut.LengthIs(); i++)
    {
        ut.GetNextItem(input);
        cout<<input<<" "<<endl;
    }

    cout<<"The length of the list is : "<<ut.LengthIs();
    ut.InsertItem(1);

    ut.ResetList();
    cout<<endl;
    for (int i=0; i<ut.LengthIs(); i++)
    {
        ut.GetNextItem(input);
        cout<<input<<" ";
    }
    cout<<endl;
    int a=4;
    bool f;
    ut.RetrieveItem(a,f);
    if (f==true)
    {
        cout<<"The item is found";

    }

    else
    {
        cout<<"The item is not found";
    }
    cout<<endl;
    a=5;
    ut.RetrieveItem(a,f);
    if (f==true)
    {
        cout<<"The item is found";

    }

    else
    {
        cout<<"The item is not found";
    }
    cout<<endl;
    a=9;
    ut.RetrieveItem(a,f);
    if (f==true)
    {
        cout<<"The item is found";

    }

    else
    {
        cout<<"The item is not found";
    }
    cout<<endl;
    a=10;
    ut.RetrieveItem(a,f);
    if (f==true)
    {
        cout<<"The item is found";

    }

    else
    {
        cout<<"The item is not found";
    }
    cout<<endl;
    if (ut.IsFull()== true)
    {
        cout<<"The list is full";
        cout<<endl;
    }
    else
    {
        cout<<"the list is not full";
        cout<<endl;
    }
    ut.DeleteItem(5);
    if (ut.IsFull()== true)
    {
        cout<<"The list is full";
        cout<<endl;
    }
    else
    {
        cout<<"the list is not full";
        cout<<endl;
    }

    ut.DeleteItem(1);
    ut.ResetList();
    for (int i=0; i<ut.LengthIs(); i++)
    {
        ut.GetNextItem(input);
        cout<<input<<" ";
    }
    cout<< endl;
    ut.DeleteItem(6);
    ut.ResetList();
    for (int i=0; i<ut.LengthIs(); i++)
    {
        ut.GetNextItem(input);
        cout<<input<<" ";
    }
    cout<<endl;
    UnsortedType <studentInfo> st;
    st.InsertItem(studentInfo (15234, "Jon", 2.6));
    st.InsertItem(studentInfo (13732, "Tyrion", 3.9));
    st.InsertItem(studentInfo (13569, "Sandor", 1.2));
    st.InsertItem(studentInfo (15467, "Ramsey", 3.1));
    st.InsertItem(studentInfo (16285, "Arya", 3.1));
    st.InsertItem(studentInfo (15467, "", 0));

    a = 13569;
    studentInfo foundStudent;
    st.RetrieveItem(a,f);
    if (f==true)
    {
        cout << "Student with Id "<<a <<"is found" << endl;
        foundStudent.PrintInfo();
    }
    else
    {
        cout << "Student with Id "<<a <<"is not found" << endl;
    }
    st.ResetList();
    studentInfo studentRecord;
    for(int i=0; i<st.LengthIs; i++)
    {
        st.GetNextItem(studentRecord);
        studentRecord.PrintInfo();
    }
    return 0;

}
