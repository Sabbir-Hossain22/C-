#include <iostream>
#include "unsortedtype.h"
#include "unsortedtype.cpp"
using namespace std;
class studentInfo
{
public:
    int studentID;
    string studentName;
    double studentCGPA;
    studentInfo(){}
    studentInfo (int id, string name, double cgpa)
    {
        studentID = id;
        studentName = name;
        studentCGPA = cgpa;
    }
    void PrintInfo()
    {
        cout <<studentID << "," << studentName << "," <<studentCGPA <<endl;
    }
    bool operator == (const studentInfo &si) const
    {
        return studentID == si.studentID;
    }
     bool operator != (const studentInfo &si) const
    {
        return studentID != si.studentID;
    }
};
