#include<iostream>
#include "usortedtype.cpp"
using namespace std;
int main()
{
    UnsortedType<int> l1, l2;
    int m,n;
    cout<<"Enter input for sequence: "<<endl;
    cin>>m;
    cout<<"Enter the first sequence: "<<endl;
    for(int i=0; i<m; i++)
    {
        int data;
        cin>>data;
        l1.InsertItem(data);
    }
    cout<<"Enter the input for second sequence:"<<endl;
    cin>>n;
    cout<<"Enter second sequence: "<<endl;
    for(int i=0; i<n; i++)
    {
        int data;
        cin>>data;
        l2.InsertItem(data);
    }

    UnsortedType<int> finalList;
    int item1,item2;
    int len1=0,len2=0;
    l1.GetNextItem(item1);
    l2.GetNextItem(item2);
    while(len1<l1.LengthIs() && len2<l2.LengthIs())
    {
        if (item1>item2)
        {
            finalList.InsertItem(item1);
            len1++;
            if (len1<l1.LengthIs())
                l1.GetNextItem(item1);
        }
        else
        {
            finalList.InsertItem(item2);
            len2++;
            if (len2<l2.LengthIs())
                l2.GetNextItem(item2);
        }
    }
    while (len1<l1.LengthIs())
    {
        finalList.InsertItem(item1);
        len1++;
        if (len1<l1.LengthIs())
            l1.GetNextItem(item1);
    }
    while (len2<l2.LengthIs())
    {
        finalList.InsertItem(item2);
        len2++;
        if (len2<l2.LengthIs())                 l2.GetNextItem(item2);
    }
    int item;
    int i =0;
    cout<<"\nOutput: ";
    while (i<finalList.LengthIs())
    {
        finalList.GetNextItem(item);
        cout<<item<<" ";
        i++;
    }
    cout<<endl<<endl;
    return 0;
}

