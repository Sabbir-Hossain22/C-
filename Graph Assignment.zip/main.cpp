#include <iostream>
#include "graphtype.cpp"

using namespace std;

void Display (bool b)
{
    if (b)
    cout <<"There is an Edge"<<endl;
    else
        cout<<"There is no Edge"<<endl;
}

int main()
{
    GraphType<char>G;

    G.AddVertex('A');
    G.AddVertex('B');
    G.AddVertex('C');
    G.AddVertex('D');
    G.AddVertex('E');
    G.AddVertex('F');
    G.AddVertex('G');
    G.AddVertex('H');

    G.AddEdge('A', 'B', 1);
    G.AddEdge('A', 'C', 1);
    G.AddEdge('A', 'D', 1);

    G.AddEdge('B', 'A', 1);

    G.AddEdge('D', 'A', 1);
    G.AddEdge('D', 'E', 1);
    G.AddEdge('D', 'G', 1);
    G.AddEdge('G', 'F', 1);
    G.AddEdge('F', 'H', 1);
    G.AddEdge('H', 'E', 1);

    cout<<G.OutDegree('D')<<endl;

    Display(G.FoundEdge('A', 'D'));
    Display(G.FoundEdge('B', 'D'));

    G.DepthFirstSearch('B','E');
    G.DepthFirstSearch('E','B');

    G.BreadthFirstSearch('B', 'E');
    G.BreadthFirstSearch('E', 'B');

    G.BreadthFirstSearch('B', 'E');


    return 0;
}
