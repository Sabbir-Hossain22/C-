#include "dynArr.h"
#include <iostream>
using namespace std;

DynArray::DynArray() {
    data1 = NULL;
    size = 0;
    data2 = NULL;
    numRows = 0;
    numColumns = 0;
}

DynArray::DynArray(int s) {
    data1 = new int[s];
    size = s;
    data2 = NULL;
    numRows = 0;
    numColumns = 0;
}

DynArray::DynArray(int r, int c) {
    numRows = r;
    numColumns = c;
    size = 0;
    data1 = NULL;

    data2 = new int*[numRows];
    for (int i = 0; i < numRows; i++) {
        data2[i] = new int[numColumns];
    }
}

DynArray::~DynArray() {
    delete[] data1;

    for (int i = 0; i < numRows; i++) {
        delete[] data2[i];
    }
    delete[] data2;
}

int DynArray::getValue(int index) {
    return data1[index];
}

int DynArray::getValue(int row, int column) {
    return data2[row][column];
}

void DynArray::setValue(int index, int value) {
    data1[index] = value;
}

void DynArray::setValue(int row, int column, int value) {
    data2[row][column] = value;
}
