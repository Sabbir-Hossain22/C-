#include <iostream>
#include "dynArr.h"
using namespace std;

int main()
{
    cout << "Please enter the number of rows and columns : "<<endl;
    int numRows, numColumns;
    cin >> numRows >> numColumns;

    DynArray array2(numRows, numColumns);


    int input;
    for (int i = 0; i < numRows; i++)
    {
        for (int j = 0; j < numColumns; j++)
        {
            cout << "Enter element at position " << "[" << i << "][" << j << "] : ";
            cin >> input;
            array2.setValue(i, j, input);
        }
    }


    cout << "The elements of your matrix : "<<endl;
    for (int i = 0; i < numRows; i++)
    {
        for (int j = 0; j < numColumns; j++)
        {
            cout << array2.getValue(i, j) << " ";
        }
        cout << endl;
    }
}
