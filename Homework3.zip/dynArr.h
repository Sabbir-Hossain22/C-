#ifndef DYNARR_H_INCLUDED
#define DYNARR_H_INCLUDED

class DynArray {
private:
    int *data1;
    int size;
    int numRows;
    int numColumns;
    int **data2;
public:
    DynArray();
    DynArray(int);
    DynArray(int, int);
    ~DynArray();
    void setValue(int, int);
    void setValue(int, int, int);
    int getValue(int);
    int getValue(int, int);
};

#endif // DYNARR_H_INCLUDED
